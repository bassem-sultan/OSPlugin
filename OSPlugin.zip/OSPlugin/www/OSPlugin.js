var exec = require("cordova/exec");

let OSPlugin = {
  coolMethod: function (arg0, success, error) {
    exec(success, error, "OSPlugin", "coolMethod", [arg0]);
  },
  showToast: function (arg0, success, error) {
    exec(success, error, "OSPlugin", "showToast", [message, duration]);
  },
};

module.exports = OSPlugin;
